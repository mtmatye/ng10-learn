module.exports = {
  GENDER: ['男', '女', '其它'],
  JOB: ['法师', '战士', '刺客', '射手', '坦克'],
  authKey: 'hero-auth',
}
